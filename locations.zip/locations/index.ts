import provincesJson from "./provinces.json";
import districtsJson from "./districts.json";
import sectorsJson from "./sectors.json";
import cellsJson from "./cells.json";
import villagesJson from "./villages.json";

export {
    provincesJson,
    districtsJson,
    sectorsJson,
    cellsJson,
    villagesJson
}
